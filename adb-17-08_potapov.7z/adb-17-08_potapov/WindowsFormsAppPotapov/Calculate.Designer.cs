﻿namespace WinFormsApp
{
    partial class Calculate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFirst = new System.Windows.Forms.Label();
            this.lblSecond = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this._txtFirst = new System.Windows.Forms.TextBox();
            this._txtSecond = new System.Windows.Forms.TextBox();
            this._txtResult = new System.Windows.Forms.TextBox();
            this.btnIncrement = new System.Windows.Forms.Button();
            this.btnDecrement = new System.Windows.Forms.Button();
            this.btnIncrease = new System.Windows.Forms.Button();
            this.btnDivide = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnPow = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblFirst
            // 
            this.lblFirst.Location = new System.Drawing.Point(59, 81);
            this.lblFirst.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFirst.Name = "lblFirst";
            this.lblFirst.Size = new System.Drawing.Size(90, 36);
            this.lblFirst.TabIndex = 0;
            this.lblFirst.Text = "Первое число : ";
            this.lblFirst.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSecond
            // 
            this.lblSecond.Location = new System.Drawing.Point(66, 34);
            this.lblSecond.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSecond.Name = "lblSecond";
            this.lblSecond.Size = new System.Drawing.Size(83, 36);
            this.lblSecond.TabIndex = 1;
            this.lblSecond.Text = "Второе число :";
            this.lblSecond.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblResult
            // 
            this.lblResult.Location = new System.Drawing.Point(103, 321);
            this.lblResult.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(151, 36);
            this.lblResult.TabIndex = 2;
            this.lblResult.Text = "Результат :";
            this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // _txtFirst
            // 
            this._txtFirst.Location = new System.Drawing.Point(154, 90);
            this._txtFirst.Margin = new System.Windows.Forms.Padding(2);
            this._txtFirst.Name = "_txtFirst";
            this._txtFirst.Size = new System.Drawing.Size(100, 20);
            this._txtFirst.TabIndex = 3;
            this._txtFirst.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TxtFirst_KeyDown);
            this._txtFirst.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtFirst_KeyPress);
            // 
            // _txtSecond
            // 
            this._txtSecond.Location = new System.Drawing.Point(154, 43);
            this._txtSecond.Margin = new System.Windows.Forms.Padding(2);
            this._txtSecond.Name = "_txtSecond";
            this._txtSecond.Size = new System.Drawing.Size(100, 20);
            this._txtSecond.TabIndex = 4;
            this._txtSecond.TextChanged += new System.EventHandler(this._txtSecond_TextChanged);
            this._txtSecond.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TxtFirst_KeyDown);
            this._txtSecond.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtFirst_KeyPress);
            // 
            // _txtResult
            // 
            this._txtResult.Location = new System.Drawing.Point(258, 330);
            this._txtResult.Margin = new System.Windows.Forms.Padding(2);
            this._txtResult.Name = "_txtResult";
            this._txtResult.ReadOnly = true;
            this._txtResult.Size = new System.Drawing.Size(323, 20);
            this._txtResult.TabIndex = 5;
            this._txtResult.TabStop = false;
            // 
            // btnIncrement
            // 
            this.btnIncrement.Font = new System.Drawing.Font("Courier New", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnIncrement.Location = new System.Drawing.Point(277, 43);
            this.btnIncrement.Margin = new System.Windows.Forms.Padding(2);
            this.btnIncrement.Name = "btnIncrement";
            this.btnIncrement.Size = new System.Drawing.Size(40, 40);
            this.btnIncrement.TabIndex = 6;
            this.btnIncrement.Text = "+";
            this.btnIncrement.UseVisualStyleBackColor = true;
            this.btnIncrement.Click += new System.EventHandler(this.Btn_Click);
            // 
            // btnDecrement
            // 
            this.btnDecrement.Font = new System.Drawing.Font("Courier New", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDecrement.Location = new System.Drawing.Point(277, 82);
            this.btnDecrement.Margin = new System.Windows.Forms.Padding(2);
            this.btnDecrement.Name = "btnDecrement";
            this.btnDecrement.Size = new System.Drawing.Size(40, 40);
            this.btnDecrement.TabIndex = 7;
            this.btnDecrement.Text = "-";
            this.btnDecrement.UseVisualStyleBackColor = true;
            this.btnDecrement.Click += new System.EventHandler(this.Btn_Click);
            // 
            // btnIncrease
            // 
            this.btnIncrease.Font = new System.Drawing.Font("Courier New", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnIncrease.Location = new System.Drawing.Point(321, 43);
            this.btnIncrease.Margin = new System.Windows.Forms.Padding(2);
            this.btnIncrease.Name = "btnIncrease";
            this.btnIncrease.Size = new System.Drawing.Size(40, 40);
            this.btnIncrease.TabIndex = 8;
            this.btnIncrease.Text = "*";
            this.btnIncrease.UseVisualStyleBackColor = true;
            this.btnIncrease.Click += new System.EventHandler(this.Btn_Click);
            // 
            // btnDivide
            // 
            this.btnDivide.Font = new System.Drawing.Font("Courier New", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDivide.Location = new System.Drawing.Point(321, 82);
            this.btnDivide.Margin = new System.Windows.Forms.Padding(2);
            this.btnDivide.Name = "btnDivide";
            this.btnDivide.Size = new System.Drawing.Size(40, 40);
            this.btnDivide.TabIndex = 9;
            this.btnDivide.Text = ":";
            this.btnDivide.UseVisualStyleBackColor = true;
            this.btnDivide.Click += new System.EventHandler(this.Btn_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(238, 192);
            this.btnExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(108, 44);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Выход";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // btnPow
            // 
            this.btnPow.Font = new System.Drawing.Font("Courier New", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnPow.Location = new System.Drawing.Point(365, 43);
            this.btnPow.Margin = new System.Windows.Forms.Padding(2);
            this.btnPow.Name = "btnPow";
            this.btnPow.Size = new System.Drawing.Size(74, 79);
            this.btnPow.TabIndex = 11;
            this.btnPow.Text = "x^2\r\n";
            this.btnPow.UseVisualStyleBackColor = true;
            this.btnPow.Click += new System.EventHandler(this.Btn_Click);
            // 
            // Calculate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.btnPow);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnDivide);
            this.Controls.Add(this.btnIncrease);
            this.Controls.Add(this.btnDecrement);
            this.Controls.Add(this.btnIncrement);
            this.Controls.Add(this._txtResult);
            this.Controls.Add(this._txtSecond);
            this.Controls.Add(this._txtFirst);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.lblSecond);
            this.Controls.Add(this.lblFirst);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Calculate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Простой калькулятор";
            this.Load += new System.EventHandler(this.Calculate_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFirst;
        private System.Windows.Forms.Label lblSecond;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.TextBox _txtFirst;
        private System.Windows.Forms.TextBox _txtSecond;
        private System.Windows.Forms.TextBox _txtResult;
        private System.Windows.Forms.Button btnIncrement;
        private System.Windows.Forms.Button btnDecrement;
        private System.Windows.Forms.Button btnIncrease;
        private System.Windows.Forms.Button btnDivide;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnPow;
    }
}
