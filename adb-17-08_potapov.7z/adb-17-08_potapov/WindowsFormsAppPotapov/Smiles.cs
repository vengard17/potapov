﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class Smiles : Form
    {
        public Smiles()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void picHappy_Click(object sender, EventArgs e)
        {
            

            picSmile.BorderStyle = BorderStyle.None; // Нет рамки
            picFrown.BorderStyle = BorderStyle.None; // Нет рамки
            picHappy.BorderStyle = BorderStyle.FixedSingle; // Рамка
            lblMessage.Text = "Щелкнули по первому рисунку";
        }


        private void picFrown_Click(object sender, EventArgs e)
        {
            picSmile.BorderStyle = BorderStyle.None; // Нет рамки
            picFrown.BorderStyle = BorderStyle.FixedSingle; // Рамка
            picHappy.BorderStyle = BorderStyle.None; // Нет рамки
            lblMessage.Text = "Щелкнули по второму рисунку";
            CallPassword();
        }
        static void CallPassword()
        {
            string password = InputPassword.Show(
        "Окно аутентификации пользователя",
          "Просим ввести Ваш пароль:");
            if (password != "root")// Плохой способ хранения пароля
            {
                MessageBox.Show(
                "Извините, но Вам не разрешено\n" // Сообщение
                + "пользоваться этой суперпрограммой!!!",
                "Неверный пароль", // Заголовок окна
                MessageBoxButtons.OK, // Кнопка OK
                MessageBoxIcon.Stop);// Критическая иконка

            }

        }

        private void picSmile_Click(object sender, EventArgs e)
        {
            picSmile.BorderStyle = BorderStyle.FixedSingle; // Рамка
            picFrown.BorderStyle = BorderStyle.None; // Нет рамки
            picHappy.BorderStyle = BorderStyle.None; // Нет рамки
            lblMessage.Text = "Щелкнули по третьему рисунку";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); // Закрыть форму
        }
        static void Main()
        {
            Application.Run(new Smiles());
        }
    }
}
