﻿namespace WindowsFormsApp
{
    partial class Smiles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Smiles));
            this.btnExit = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.picFrown = new System.Windows.Forms.PictureBox();
            this.picHappy = new System.Windows.Forms.PictureBox();
            this.picSmile = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picFrown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHappy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSmile)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.AutoSize = true;
            this.btnExit.Location = new System.Drawing.Point(272, 292);
            this.btnExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(56, 23);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Выход";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblMessage.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblMessage.ForeColor = System.Drawing.Color.Red;
            this.lblMessage.Location = new System.Drawing.Point(20, 212);
            this.lblMessage.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(554, 44);
            this.lblMessage.TabIndex = 4;
            this.lblMessage.Text = "Щелкайте по смайликам";
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblMessage.Click += new System.EventHandler(this.label1_Click);
            // 
            // picFrown
            // 
            this.picFrown.Image = ((System.Drawing.Image)(resources.GetObject("picFrown.Image")));
            this.picFrown.Location = new System.Drawing.Point(208, 59);
            this.picFrown.Margin = new System.Windows.Forms.Padding(2);
            this.picFrown.Name = "picFrown";
            this.picFrown.Size = new System.Drawing.Size(174, 121);
            this.picFrown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picFrown.TabIndex = 2;
            this.picFrown.TabStop = false;
            this.picFrown.Click += new System.EventHandler(this.picFrown_Click);
            // 
            // picHappy
            // 
            this.picHappy.Image = ((System.Drawing.Image)(resources.GetObject("picHappy.Image")));
            this.picHappy.Location = new System.Drawing.Point(9, 59);
            this.picHappy.Margin = new System.Windows.Forms.Padding(2);
            this.picHappy.Name = "picHappy";
            this.picHappy.Size = new System.Drawing.Size(160, 121);
            this.picHappy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picHappy.TabIndex = 1;
            this.picHappy.TabStop = false;
            this.picHappy.Click += new System.EventHandler(this.picHappy_Click);
            // 
            // picSmile
            // 
            this.picSmile.Image = ((System.Drawing.Image)(resources.GetObject("picSmile.Image")));
            this.picSmile.Location = new System.Drawing.Point(424, 59);
            this.picSmile.Margin = new System.Windows.Forms.Padding(2);
            this.picSmile.Name = "picSmile";
            this.picSmile.Size = new System.Drawing.Size(167, 121);
            this.picSmile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSmile.TabIndex = 0;
            this.picSmile.TabStop = false;
            this.picSmile.Click += new System.EventHandler(this.picSmile_Click);
            // 
            // Smiles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.picFrown);
            this.Controls.Add(this.picHappy);
            this.Controls.Add(this.picSmile);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Smiles";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Smiles - Упражнение №1";
            ((System.ComponentModel.ISupportInitialize)(this.picFrown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHappy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSmile)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picSmile;
        private System.Windows.Forms.PictureBox picHappy;
        private System.Windows.Forms.PictureBox picFrown;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblMessage;
    }
}