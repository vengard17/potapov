﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp
{
    public partial class Calculate : Form
    {
        public Calculate()
        {
            InitializeComponent();
        }



        private bool _isNumber = false;


        private void TxtFirst_KeyDown(object sender, KeyEventArgs e)
        {
            _isNumber = e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9 //основная клавиатура
            || e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9 // дополнительная клавиатура
            || e.KeyCode == Keys.Back;
        }

        private void TxtFirst_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox box = (TextBox)sender;
            switch (e.KeyChar) //Переключатель
            {
                case '-': // Разрешаем минус, если он первый
                    if (box.Text.Length == 0)
                        _isNumber = true;
                    break;
                case '.': // точка не должна быть первой
                    if (box.Text.Length == 0)
                        break;
                    // точка не должна следовать за минусом
                    if (box.Text[0] == '-' && box.Text.Length == 1)
                        break;
                    // точка должна быть одна
                    if (box.Text.IndexOf('.') == -1)
                        _isNumber = true; // Ещё не было точек
                    break;
            }
            //Запрещаем в текстовом поле лишние символы
            if (!_isNumber)
                e.Handled = true;
        }
        //Объявляем числовые переменные как поля-члены класса
        //Их можно объявить как локальные и внутри обработчика btn_Click()
        //Но оставляем область видимости класс, вдруг где-то пригодятся
        private double _numFirst, _numSecond, _numResult;

        private void _txtSecond_TextChanged(object sender, EventArgs e)
        {

        }

        private void Calculate_Load(object sender, EventArgs e)
        {

        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Один обработчик для всех кнопок операций
        private void Btn_Click(object sender, EventArgs e)
        {
            //Копируем текстовые поля в локальные переменные
            string strFirst = string.Copy(_txtFirst.Text);
            string strSecond = string.Copy(_txtSecond.Text);

            //Замена в строке точки символом запятой для корректного преобразования в число
            int pos = strFirst.IndexOf('.');
            if (pos != -1)
            {
                strFirst = strFirst.Substring(0, pos) + ','
                    + strFirst.Substring(pos + 1);
            }
            pos = strSecond.IndexOf('.');
            if (pos != -1)
            {
                strSecond = strSecond.Substring(0, pos) + ','
                    + strSecond.Substring(pos + 1);
            }
            //Преобразуем текст в число для выполнения операций
            if (_txtFirst.Text.Length > 0)
                _numFirst = Convert.ToDouble(strFirst);
            else
                _numFirst = 0.0D;
            if (_txtSecond.Text.Length > 0)
                _numSecond = Convert.ToDouble(strSecond);
            else
                _numSecond = 0.0D;

            //Выполняем нужную операцию 
            string btnText = "";//создали строковую переменную
            bool divideFlag = false;//флаг деления на ноль
            Button btn = (Button)sender; // Явное приведение типов для распознования кнопок
            switch (btn.Name)// Переключатель
            {
                case "btnIncrement"://Операция сложения
                    btnText = "\"+\"";// Экран ковычек
                    _numResult = _numFirst + _numSecond;
                    break;
                case "btnDecrement"://Операция вычетания
                    btnText = "\"-\"";//Экран ковычек
                    _numResult = _numFirst - _numSecond;
                    break;
                case "btnIncrease"://Операция умножения
                    btnText = "\"*\"";//Экран ковычек
                    _numResult = _numFirst * _numSecond;
                    break;
                case "btnDivide"://Операция деления
                    btnText = "\":\"";// экран ковычек
                    //проверяем корректность деления
                    if (Math.Abs(_numSecond) < 1.0E-30)
                    {
                        MessageBox.Show(
                     "Делить на ноль нельзя!",//Сообщение
                     "Ошибка",// Заголовок окна
                     MessageBoxButtons.OK,//Кнопка ОК
                     MessageBoxIcon.Stop);//Критическая иконка
                        divideFlag = true;
                    }
                    else
                        _numResult = _numFirst / _numSecond;
                    break;
                case "btnPow": //Возведение в квадрат
                    btnText = "\"Pow\"";//
                    _numResult = Math.Pow(_numFirst, 2);
                    break;

            }
            //Для отображения в панели Output режима Debug
            System.Diagnostics.Debug.WriteLine("Нажата кнопка " + btnText);//Конкатенция

            //Отображение результата
            if (!divideFlag)
            {
                _txtResult.Text = Convert.ToString(_numResult);
                this.Validate();//Обновить экран 
            }
        }
    }
}
