﻿namespace CircleButtonTest
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.circleButton22 = new MyCompany.UserControls.CircleButton2(this.components);
            this.circleButton21 = new MyCompany.UserControls.CircleButton2(this.components);
            this.circleButton3 = new MyCompany.UserControls.CircleButton(this.components);
            this.circleButton2 = new MyCompany.UserControls.CircleButton(this.components);
            this.circleButton1 = new MyCompany.UserControls.CircleButton(this.components);
            this.SuspendLayout();
            // 
            // circleButton22
            // 
            this.circleButton22.Location = new System.Drawing.Point(263, 166);
            this.circleButton22.Name = "circleButton22";
            this.circleButton22.Size = new System.Drawing.Size(100, 100);
            this.circleButton22.TabIndex = 4;
            this.circleButton22.Text = "circleButton22";
            this.circleButton22.UseVisualStyleBackColor = true;
            this.circleButton22.Click += new System.EventHandler(this.circleButton_Click2);
            // 
            // circleButton21
            // 
            this.circleButton21.Location = new System.Drawing.Point(106, 165);
            this.circleButton21.Name = "circleButton21";
            this.circleButton21.Size = new System.Drawing.Size(100, 100);
            this.circleButton21.TabIndex = 3;
            this.circleButton21.Text = "circleButton21";
            this.circleButton21.UseVisualStyleBackColor = true;
            this.circleButton21.Click += new System.EventHandler(this.circleButton_Click2);
            // 
            // circleButton3
            // 
            this.circleButton3.Location = new System.Drawing.Point(329, 60);
            this.circleButton3.Name = "circleButton3";
            this.circleButton3.Size = new System.Drawing.Size(100, 100);
            this.circleButton3.TabIndex = 2;
            this.circleButton3.Text = "circleButton3";
            this.circleButton3.UseVisualStyleBackColor = true;
            this.circleButton3.Click += new System.EventHandler(this.circleButton_Click);
            // 
            // circleButton2
            // 
            this.circleButton2.Location = new System.Drawing.Point(185, 59);
            this.circleButton2.Name = "circleButton2";
            this.circleButton2.Size = new System.Drawing.Size(100, 100);
            this.circleButton2.TabIndex = 1;
            this.circleButton2.Text = "circleButton2";
            this.circleButton2.UseVisualStyleBackColor = true;
            this.circleButton2.Click += new System.EventHandler(this.circleButton_Click);
            // 
            // circleButton1
            // 
            this.circleButton1.Location = new System.Drawing.Point(24, 59);
            this.circleButton1.Name = "circleButton1";
            this.circleButton1.Size = new System.Drawing.Size(100, 100);
            this.circleButton1.TabIndex = 0;
            this.circleButton1.Text = "circleButton1";
            this.circleButton1.UseVisualStyleBackColor = true;
            this.circleButton1.Click += new System.EventHandler(this.circleButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(457, 470);
            this.Controls.Add(this.circleButton22);
            this.Controls.Add(this.circleButton21);
            this.Controls.Add(this.circleButton3);
            this.Controls.Add(this.circleButton2);
            this.Controls.Add(this.circleButton1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private MyCompany.UserControls.CircleButton circleButton1;
        private MyCompany.UserControls.CircleButton circleButton2;
        private MyCompany.UserControls.CircleButton circleButton3;
        private MyCompany.UserControls.CircleButton2 circleButton21;
        private MyCompany.UserControls.CircleButton2 circleButton22;
    }
}

