﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyCompany.UserControls;

namespace CircleButtonTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void circleButton_Click(object sender, EventArgs e)
        {
            
            // Создаем псевдоним переданной ссылки
            CircleButton button = sender as CircleButton;
            CircleButton2 button2 = sender as CircleButton2;

            if (button != null)
                MessageBox.Show("Нажата кнопка: " + button.Name);
        }

        private void circleButton_Click2(object sender, EventArgs e)
        {
            // Создаем псевдоним переданной ссылки
            CircleButton2 button2 = sender as CircleButton2;

            if (button2 != null)
                MessageBox.Show("Нажата кнопка: " + button2.Name);
        }
    }
}
