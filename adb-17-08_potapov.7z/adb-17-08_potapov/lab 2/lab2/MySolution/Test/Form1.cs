﻿using MyCompany.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ButtonOnClick(object sender, EventArgs e)
        {
            string msg;

            if (textBox1.Text.Trim().Length == 0)
                msg = "Щелкнули на кнопке";
            else
                msg = textBox1.Text.Trim();
            //запускаем наше диалоговое окно статическим методом
            MyDialogBox.Show(msg, this.Text);

        }
    }
}
