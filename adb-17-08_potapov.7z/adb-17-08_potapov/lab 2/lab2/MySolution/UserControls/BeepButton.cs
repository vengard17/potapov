﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.Media;

namespace MyCompany.UserControls
{
    public partial class BeepButton : Button
    {
        public BeepButton()
        {
            InitializeComponent();
        }

        public BeepButton(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }
        protected override void OnClick(EventArgs e)
        {
            SystemSounds.Beep.Play();
            base.OnClick(e);
        }

    }
}