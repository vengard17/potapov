﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyCompany.UserControls
{
    public partial class MyDialogForm : Form
    {
        public MyDialogForm()
        {
            InitializeComponent();
        }

        private void btnDialog_Click(object sender, EventArgs e)
        {
            MessageBox.Show("\t \t ВНИМАНИЕ! \n Вы уверены, что хотите завершить работу? " );
        }
    }
}
