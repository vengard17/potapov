﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
namespace MyCompany.StudName
{
    public partial class ClickmaticButton : Button // : Component
    {
        // Переопределение унаследованного метода диспетчеризации
        // события MouseMove увода курсора за область чувствительности элемента
        protected override void OnMouseMove(MouseEventArgs mevent)
        {
            base.OnMouseMove(mevent);
            // Приостанавливаем или возобнавляем запущенный таймер логическим выражением
            timer1.Enabled = this.Capture // Связь с мышью установлена
            // && (MouseButtons & MouseButtons.Left) != 0 // Распознавать левую кнопку необязательно
                            && this.ClientRectangle.Contains(mevent.Location); // Курсор над кнопкой
            // &&
            this.ClientRectangle.Contains(this.PointToClient(MousePosition));// То же самое!
        }

        // Переопределение унаследованного метода диспетчеризации
        // события MouseDown нажатия кнопки мыши для запуска таймера
        protected override void OnMouseDown(MouseEventArgs mevent)
        {
            base.OnMouseDown(mevent); // Отправляем к базовому методу
                                      // Если нажата левая кнопка мыши (побитовое умножение)
            if ((mevent.Button & MouseButtons.Left) != 0)
            {
                timer1.Interval = DELAY; // Задержка для момента нажатия
            timer1.Start(); // Запустить таймер
            }
        }

        // Переопределение унаследованного метода диспетчеризации
        // события MouseUp отпускания кнопки мыши для остановки таймера
        protected override void OnMouseUp(MouseEventArgs mevent)
        {
            base.OnMouseUp(mevent); // Отправляем к базовому методу
            timer1.Stop(); // Стоп таймер
        }

        public ClickmaticButton()
        {
            InitializeComponent();
        }
        public ClickmaticButton(IContainer container)
        {
            container.Add(this);
            InitializeComponent();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            timer1.Interval = SPEED; // Устанавливаем новый интервал генерации тиков
            this.OnClick(EventArgs.Empty); // Генерируем щелчок на элементе кнопки
            // с пустым фактическим параметром
        }

        // Поля характеристик работы таймера 
        readonly int DELAY = 250 * (1 + SystemInformation.KeyboardDelay);
        readonly int SPEED = 405 - 12 * SystemInformation.KeyboardSpeed;
        private void Timer_Tick(object sender, EventArgs e)
        {
        }
    }
}