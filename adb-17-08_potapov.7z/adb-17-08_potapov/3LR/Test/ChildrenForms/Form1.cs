﻿using System;
using System.Windows.Forms;

namespace MyCompany.StudName
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnClickGen_Click(object sender, EventArgs e)
        {
            int tickCount;
            if (!Int32.TryParse(lblTickCount.Text, out tickCount))
                tickCount = 1; // При некорректном преобразовании установить 1
            else
                tickCount++; // При корректоном преобразовании увеличить на 1
            lblTickCount.Text = tickCount.ToString();
        }

        private void BtnClickGen_Click_1(object sender, EventArgs e)
        {
            int tickCount;
            if (!Int32.TryParse(lblTickCount.Text, out tickCount))
                tickCount = 1; // При некорректном преобразовании установить 1
            else
                tickCount++; // При корректоном преобразовании увеличить на 1
            lblTickCount.Text = tickCount.ToString();
        }
    }
}
