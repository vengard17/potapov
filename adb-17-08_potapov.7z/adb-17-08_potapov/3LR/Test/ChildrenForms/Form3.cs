﻿using System;
using System.Windows.Forms;

namespace MyCompany.StudName
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();

            numericScan1.DecimalPlaces =
            numericScan2.DecimalPlaces = 2;
            numericScan1.Increment =
            numericScan2.Increment = 0.01M;
        }

        private void NumericScanOnValueChanged(object sender, EventArgs e)
        {
            label1.Text = "Первый: " + numericScan1.Value +
                "; Второй: " + numericScan2.Value;
            label2.Text = "Произведение: " + numericScan1.Value * numericScan2.Value;
        }

    }
}
